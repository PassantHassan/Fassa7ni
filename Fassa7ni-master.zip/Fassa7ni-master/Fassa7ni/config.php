<?PHP
	$host = "localhost";
	$username = "root";
	$password = "";
	$database = "fassa7ni";
	$con = mysqli_connect($host, $username, $password, $database) or die ("Couldn't connect to database");
?>