# Fassa7ni


### It’s a web-site that recommends for you places to go based on your needs and your location.
### There are 5 categories you choose from “fun, coffee , food ,Nightlife , shopping”
### When you select one of categories there is a page contains recommended  places depends on your location and their rate and you have the ### ability to see others comments on this places and rating of this place and you have the ability to interact with the website and make ### your own review and write your comment on this place


## Tecnologies :
### PHP
### Javascript
### Ajax
### Bootstrap
### HTML
### CSS
### Google Maps API
### Here Maps API


## Team Members :
### Abdullah Hassan
### Amr Mohamed
### Mohamed Adel
### Sara Ashraf


## Under Supervision :
### Dr.Mohamed Mostafa El-Taweel
### Eng.Alaa Sobhy


